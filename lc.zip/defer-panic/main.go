package main

import (
	"fmt"
)

// func f1(){
// 	fmt.Println("开始")
// 	defer func(){
// 		fmt.Println("aaaa")
// 		fmt.Println("bbbb")
// 	}()
// 	fmt.Println("结束")
// }

// //匿名返回值
// func f2() int{

// 	var a int // a=0默认
// 	fmt.Println("开始")
// 	defer func(){
// 		a++
// 	}()
// 	// 这种情况下，返回的a是0， 而不是1
// 	return a
// }

// //命名返回值
// func f3() (a int){

// 	fmt.Println("开始")
// 	defer func(){
// 		a++
// 	}()
// 	//这种情况下，返回1
// 	return a
// }

// func main(){
// 	f1()
// 	fmt.Println("---------")
// 	fmt.Println(f2())
// 	fmt.Println("---------")
// 	fmt.Println(f3())



// //匿名返回值和命名返回值在defer的情况下的例子
// func f1() int{
// 	x := 5
// 	defer func(){
// 		x++
// 	}()

// 	return x // 返回值是5
// }

// func f2() (x int){
// 	// x := 5
// 	defer func(){
// 		x ++
// 	}()
// 	// return 5 实际上是给x int这里的x赋值为5,，然后执行defer中的函数，再给x加1
// 	return 5 //返回值是6， 因为我们定义函数的时候，指定了返回的值是x
// }

// func f3() (y int){
// 	x := 5
// 	defer func(x int){
// 		x ++
// 	}(x)

// 	return x //返回值是5 如果把上面的y int改成 x int，那么返回值就是6
// }

// func f4() (x int){
// 	//这个defer里边虽然用的是x，但是实际上和外边的x完全不是一回事
// 	//比如这里的x可以变成y
// 	defer func(x int){
// 		x ++
// 	}(x)

// 	return 5 //返回值是5
// }

// func main(){
// 	fmt.Println(f1())
// 	fmt.Println(f2())
// 	fmt.Println(f3())
// 	fmt.Println(f4())
// }



// }