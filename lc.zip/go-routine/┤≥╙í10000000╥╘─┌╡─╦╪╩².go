package main

import (
	"fmt"
	// "sync"
	"time"
	// "runtime"
)

//引入wait group 机制，可以保证主线程提前运行完之后，他要等待协程也全部结束才会退出
// var wg sync.WaitGroup

//统计素数 -- 就是只有1和他本身能够整除的数

func main(){
	start := time.Now().Unix()
	for num:=2; num<=120000; num++{
		var flag = true
		for i:=2; i < num; i++{
			if num%i == 0{
				flag = false
				break
			}
		}
		if flag{
			// fmt.Println(num)
		}
	}
	end := time.Now().Unix()
	fmt.Println(end-start)
}



