package main

import(
	"fmt"
	"sync"
	"time"
)

var count = 0
var wg sync.WaitGroup
var mutex sync.Mutex

func lockTest(){
	//加上互斥锁
	mutex.Lock()
	defer wg.Done()
	count ++
	fmt.Println("The count is: ",count)
	time.Sleep(time.Millisecond*50)
	//解除互斥锁
	mutex.Unlock()
}

func main(){
	for i:=0;i<20;i++{
		wg.Add(1)
		go lockTest()
	}
	wg.Wait()
}