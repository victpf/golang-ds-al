package main

import (
	"fmt"
	"sync"
)

var wg sync.WaitGroup

func hello(){
	defer wg.Done()
	for i:=0;i<10;i++{
		fmt.Println("hello,go")
	}
}

func error() {
	defer wg.Done()
	//处理出现的异常,以保证hello函数能够正常执行
	//否则当error无法执行的时候，hello的协程也不会执行
	defer func(){
		if err := recover(); err != nil{
			fmt.Println("error() 函数发生错误",err)
		}
	}()
	var myMap map[int]string 
	// myMap := make(map[int]string,2)
	myMap[0] = "haha"
	fmt.Printf("myMap: %#v",myMap)
}

func main(){
	wg.Add(1)
	go hello()
	wg.Add(1)
	go error()

	wg.Wait()
	fmt.Println("主程序结束")
}