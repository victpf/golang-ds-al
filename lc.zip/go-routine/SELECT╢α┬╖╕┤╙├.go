package main

import (
	"fmt"
	"time"
)

func main() {
	intChan := make(chan int, 10)
	for i := 0; i < 10; i++ {
		intChan <- i
	}

	stringChan := make(chan string, 5)
	for i := 0; i < 5; i++ {
		stringChan <- "hello" + fmt.Sprintf("%d", i)
	}

	//select多路复用，同时从上面两个channel中读取数据
	//使用select多路复用，不能关闭channel
	for {
		select {
		case v := <-intChan:
			fmt.Printf("从intChan读取数据%v\n", v)
			time.Sleep(time.Millisecond * 50)
		case v := <-stringChan:
			fmt.Printf("从stringChan读取数据%v\n", v)
			time.Sleep(time.Millisecond * 50)
		default:
			fmt.Println("数据读取完毕！")
			//下面必须有return 因为这里本身是一个死循环
			return
		}
	}
}
