package main

import (
	"fmt"
	"sync"
)

/*
即使写入的速度远远慢于读取的速度，我们这里也不会有问题，
读取会等有数据可读了才去读，不会中途退出或者报错
*/
//两个方法，一个写数据到channel
//另一个读数据
//两个都通过管道，通过协程的方式来进行

var wg sync.WaitGroup

func ReadChan(ch chan interface{}) {
	defer wg.Done()
	var count int = 0

	for value := range ch {
		count++
		fmt.Printf("【读取】数据成功：%v , %v times\n", value, count)
	}
}

// //下面的代码会引起死锁
// func ReadChan(ch chan interface{}) {
// 	defer wg.Done()
// 	var length = len(ch)
// 	for i := 0; i < length; i++ {
// 		var x = <-ch
// 		fmt.Printf("%v 被读出channel", x)
// 	}
// }

func WriteChan(ch chan interface{}) {
	defer wg.Done()
	for i := 0; i < 10; i++ {
		ch <- i
		// var str string = "哈哈哈"+string(i)
		var str string = "哈哈哈"
		
		ch <- fmt.Sprintf("%s%s", str, i)
		fmt.Printf("【写入】数据成功: %v, %v\n", i, fmt.Sprintf("%s%s", str, i))
	}
	//这里的close非常必要，否则会发生管道堵塞，原因就是没有close管道，然后就开始使用for range遍历管道了
	// close(ch)
}

func main() {
	var ch chan interface{} = make(chan interface{}, 5)
	wg.Add(1)
	go ReadChan(ch)

	wg.Add(1)
	go WriteChan(ch)

	wg.Wait()
	fmt.Println("主线程退出")

}
