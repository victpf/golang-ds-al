package main

import(
	"fmt"
	"sync"
	"time"
)
var wg sync.WaitGroup
var mutex sync.Mutex
// 下面这个m是一个全局变量，所以互斥锁的意义就在这
// 由于他是一个全局变量，所以当我们开启多个协程同时
// 运行factorial函数的时候，这些协程会同时更新m
// 这时候就会产生争抢和冲突，所以用互斥锁就会有效的解决
// 这样的情况
var m = make(map[int]int,0)

func factorial(num int){
	mutex.Lock()
	// var m = make(map[int]int,0)
	var sum = 1
	for i:=1;i<=num;i++{
		sum *= i 
	}
	m[num] = sum
	fmt.Printf("num: %v, factorial: %v\n",num,sum)
	time.Sleep(time.Millisecond*100)
	wg.Done()
	mutex.Unlock()
}

func main(){
	for i := 0;i<40;i++{
		wg.Add(1)
		go factorial(i)
	}

	wg.Wait()
}