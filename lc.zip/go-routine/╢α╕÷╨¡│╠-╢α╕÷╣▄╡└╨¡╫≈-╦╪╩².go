package main

import (
	"fmt"
	"sync"
	"time"
)

var wg sync.WaitGroup
const maxium = 1200000
//将1-120000的数写入channel
func putNum(ch chan int,max int){
	defer wg.Done()
	for i := 1;i<max;i++{
		ch <- i 
	}
	//这里一定要记得关闭这个channel，否则后面遍历她的时候由于用的是for range,所以会报错
	close(ch)
}

//将会开启多个协程，通过遍历上面的putNum写入的数，将其中是素数的部分写入另一个channel
func primeNum(ch chan int, chPrime chan int, exitCh chan bool){
	defer wg.Done()
	for num:= range ch{
		var flag bool = true
		for i:=2;i<num;i++{
			if num%i == 0{
				flag = false
				break
			}
		}
		if flag{
			chPrime <- num
		}
	}

	exitCh <- true
}

//打印素数
func printNum(ch chan int){
	defer wg.Done()
	for value := range ch{
		fmt.Println(value)
	}

}


func main(){
	start := time.Now().Unix()
	var inputCh = make(chan int,10000)
	var chPrime = make(chan int,500000)
	var exitCh = make(chan bool,16)

	wg.Add(1)
	go putNum(inputCh,maxium)

	for i:=0;i<16;i++{
		wg.Add(1)
		go primeNum(inputCh,chPrime,exitCh)
	}

	wg.Add(1)
	go printNum(chPrime)

	//下面这个函数是为了判断exitCh里边16个协程是不是全部结束了
	//如果是 --- 那么就可以close chPrime了
	wg.Add(1)
	go func(){
		for i:=0;i<16;i++{
			<-exitCh
		}
		//等16个协程全部结束之后，chPrime就可以关闭了
		close(chPrime)
		wg.Done()
	}()
	wg.Wait()
	end := time.Now().Unix()

	fmt.Println("主进程结束！",end - start ,"毫秒")

}

