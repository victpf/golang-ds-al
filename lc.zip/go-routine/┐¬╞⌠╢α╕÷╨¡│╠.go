package main

import (
	"fmt"
	"sync"
	"time"
)

var wg sync.WaitGroup

func test(num int){
	//协程计数器减去1
	defer wg.Done()
	for i:=1;i<=5;i++{
		fmt.Printf("协程%v 第%v条数据\n",num,i)
		time.Sleep(time.Millisecond * 100)
	}
}

//开启5个协程，每个协程都写5个数
func main(){
	for i:=1;i<=5;i++{
		wg.Add(1)
		go test(i)
	}
	wg.Wait()
	fmt.Println("关闭主线程...")
}