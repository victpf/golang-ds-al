package main

import (
	"errors"
	"fmt"
)

func main() {
	/*
		1. error: 内置的数据类型，内置的接口
			定义方法:Error() string
		2. 使用go语言提供好的包
			--- errors包下面的 errors.New()，创建一个error对象
			--- fmt.Errorf(format string, a ...interface()) error
	*/

	//1.创建一个error 数据
	err1 := errors.New("自己创建的error")
	fmt.Println(err1)
	fmt.Printf("类型: %T\n", err1)

	//2.另一种创建error的方法
	err2 := fmt.Errorf("错误的信息码：%d", 250)
	fmt.Println(err2)
	fmt.Printf("类型：%T\n", err2)
}
