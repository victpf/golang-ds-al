package main

// 这种import  方式的第一种用法，就是可以让调用相应的库的方法的时候
// 不必在前面加上库的名字
import _ "fmt"

func main() {
	println("lalala")
}
