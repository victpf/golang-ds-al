package main

import (
	"fmt"
	"net"
)

/*
某些包里边会对error信息进行封装，也就是会定义特定的结构体和结构体方法
来描述具体的错误，我们可以利用类型断言的方式，去调用了利用这些方法
*/
func main() {
	addr, err := net.LookupHost("www.bbbasssidu.com")
	fmt.Println(err)
	fmt.Println(addr)
	/*
		在这里，我们首先通过查看LookupHost方法的源码，发现了她有特殊的结构体来描述他的错误类型
		然后我们进去就发现了那个结构体，并且与之相关的方法
	*/
	if ins, ok := err.(*net.DNSError); ok {
		if ins.Timeout() {
			fmt.Println("超时错误。。。")
		} else if ins.Temporary() {
			fmt.Println("临时性的错误。。。")
		} else {
			fmt.Println("常规错误")
		}
	}
}
