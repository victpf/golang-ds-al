package main

import (
	"fmt"
)

func fn1(x int){
	x = 10
}

func fn2(x *int){
	*x = 40
}

func main(){
	var a *int
	a = new(int)
	*a = 100
	fmt.Println(*a)

	// var userinfo = make(map[string]string)
	// userinfo["username"] = "ZHANG SAN"
	// userinfo["age"] = "22"
	// fmt.Println(userinfo)

	// a := 1
	// fn1(a)
	// fmt.Println(a)

	// fn2(&a)
	// fmt.Println(a)


	// a := 10
	// p := &a
	// *p = 100
	// fmt.Println(p)
	// fmt.Println(*p)
// 	var a = 10
// 	var p = &a
// 	fmt.Printf("a的值： %v a的类型: %T a的地址: %p\n",a,a,&a)
// 	fmt.Printf("p的值： %v p的类型：%T, p的地址: %p",p,p,&p)

	// var a = 10
	// var p = &a
	// fmt.Printf("a的值： %v a的类型: %T a的地址: %p\n",a,a,&a)
	// fmt.Printf("p的值： %v p的类型：%T",p,p)
}

// func main(){
// 	http.HandleFunc("/",func(http.ResponseWriter, *http.Request) {
// 		log.Println("Hello World!")
// 	})

// 	http.HandleFunc("/bye",func(http.ResponseWriter, *http.Request) {
// 		log.Println("Bye!")
// 	})

// 	http.ListenAndServe(":9090",nil)

// }