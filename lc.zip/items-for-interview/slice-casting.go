package main

import "fmt"

func main() {
	slice := []int{0, 1, 2, 3, 4, 5, 6, 7}
	// sliceCast和原来的slice共同指向一个底层数组，
	// sliceCast长度没有超过cap,所以不会重新分配内存，所以append的时候，会替换原来的slice相应的位置的值
	// 所以输出的结果是：
	// slice:  [0 1 2 4 4 5 6 7] --sliceCast:  [0 1 2 4]
	sliceCast := slice[:3]
	sliceCast = append(sliceCast, 4)
	fmt.Println("slice: ", slice, "--sliceCast: ", sliceCast)
}
