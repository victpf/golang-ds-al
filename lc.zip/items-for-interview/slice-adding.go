package main

import "fmt"

func main() {
	slice := []int{1, 2, 3}
	// golang是值传递，所以这里边遍历一开始就决定了只有开始遍历的时候slice的内容，因为实际上这里的slice是从上面的copy了一份
	// 同时，由于遍历的是slice并且只有一个变量接收，所以是slice的index,
	// 由于遍历开始的时候，slice的长度是3，所以i只会有3个值[0,1,2]
	// 所以最后的结果是[1,2,3,0,1,2]
	for i := range slice {
		slice = append(slice, i)
	}
	fmt.Println(slice)
}
