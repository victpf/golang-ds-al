package main

import "fmt"

func main() {
	var x interface{} = "hello"
	if y, ok := x.(string); ok {
		fmt.Printf("%T\n", y)
		fmt.Println(y)
	}
}
