package main

import "fmt"

func main(){
	var x int = 122.5+123.7
	fmt.Println(x)
}
