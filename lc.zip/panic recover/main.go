package main

import (
	"fmt"
	"errors"
)

/*
go中没有异常机制，使用panic和recover来处理错误
*/

// func fn1(){
// 	fmt.Println("fn1")
// }

// // func fn2(){
// // 	defer func(){
// // 		err := recover()
// // 		if err != nil{
// // 			fmt.Println(err)
// // 		}
// // 	}()
// // 	panic("抛出一个异常")
// // }


// 使用recover捕获异常
// func fn1(x, y int){
// 	defer func(){
// 		err := recover()
// 		if err != nil{
// 			fmt.Println("error: ",err)
// 		}
// 	}()
// 	// fmt.Println(x/y)
// }


//综合使用panic recover的例子

func readFile(fileName string) error{
	if fileName == "main.go"{
		return nil
	} else {
		return errors.New("读取文件失败")
	}
}

func fn(){
	defer func(){
		e := recover()
		if e != nil{
			fmt.Println("给管理员发邮件")
		}
	}()
	err := readFile("xxx.go")
	if err != nil{
		panic(err)
	}
}

func main(){
	fn()
	fmt.Println("继续执行")
}

