package main

import "sort"
import "fmt"

func threeSum(nums []int) [][]int {
	// 首先将原来的序列从小到大排序
	sort.Ints(nums)
	result := make([][]int,0)
	start := 0
	end := 0
	index := 0
	addNum := 0
	length := len(nums)
	var tmp = 0
	// 遍历整个排序过后的序列
	for index =1;index < length-1;index++{
		start = 0
		end = length -1
		tmp=0
		//如果index  当前位置的值和前面一个一样，那么start的位置就设置为前面这个值
		//下面这个实际上是如果index 这个有重复值，那么index就跳过当前这个值，直接用后面哪一个值，
		//比如前面一个index 的值是5，后面一个还是5，这时候就发现了有重复。
		//所以5的前面和后面的实际上已经检查过了，所以直接将start指向前面一个5（index-1），只需要验证这一种组合
		//因为其他的组合前面都已经验证过了
		if index >1 && nums[index] == nums[index -1]{
 			start = index -1
			//tmp =1
			//fmt.Println("index有重复！","start: ",start,"index: ",index,"nums[index]: ",nums[index],"nums[index-1]: ",nums[index-1])
		}

		// 如果开始位置和结束位置都在正常范围，对于每一个 index位置上面的数字
		// 都要检查是不是存在和等于0的组合
		// 双指针，一个在index左边(start)，一个在index(右边)
		for start < index && end > index {
			if tmp == 1{
				fmt.Println("index有重复1","start: ",start,"end: ",end)
			}
			// 如果index左边的数有重复（和前面一个位置一样的值），那么往前挪一个位置
			if start >0 && nums[start] == nums[start-1]{
				start ++
				continue
			}
			//如果index右边的位置有重复,那么往后挪一个位置
			if end < length-1 && nums[end] == nums[end+1]{
				end--
				continue
			}
			//前面都是为了去重
			//然后在这里计算index index左边的数，index右边的数 的和
			addNum = nums[start] + nums[end] +nums[index]
			// 如果和为0，那么就是一个合法的组合，同时左边前进一位，右边后退一位
			if addNum==0 {
				result = append(result,[]int{nums[start],nums[index],nums[end]})
				start ++
				end --
			} else if addNum > 0{ // 如果大于零，那么右边往前挪一个位置，继续虾夷醯循环
				end --
			} else { //如果小于零，左边往前挪一个位置，然后继续循环
				start ++
			}
		}
	}
	return result
}

func main(){
	nums := []int{-1,-1,1,1,2,3,-2}
	result := threeSum(nums)
	fmt.Println(result)
}
