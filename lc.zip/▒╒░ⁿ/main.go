package main

import (

	"fmt"
)
//闭包1 返回的函数没有参数
func addr1() func() int{
	var i = 10
	return func() int{
		return i + 1
	}
}

//闭包2 返回的函数带有参数
func addr2() func(int) int{
	var i = 10
	return func (y int) int{
		i += y
		return i
	}
}

func main(){
	//这个调用三次结果都一样，因为i对于我们这个函数来说是一个全局变量
	//而且这三次的调用都没有直接去修改i，所以无论调用几次，结果都一样
	var x = addr1()
	fmt.Println(x())
	fmt.Println(x())
	fmt.Println(x())

	//这个一样，这个闭包返回的函数里边带有参数，而且她每一次的调用都会修改i，由于闭包的机制，i对于我们返回的这个参数来说
	//是一个全局变量，所以返回的值每次都会在前面一次调用的基础上增加
	var xx = addr2()
	fmt.Println(xx(30))
	fmt.Println(xx(30))
	fmt.Println(xx(30))
}