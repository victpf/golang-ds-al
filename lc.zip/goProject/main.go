package main

import (
	"decimal"
	"fmt"
	"goProject/tools"

	"github.com/tidwall/gjson"
)

func init() {
	fmt.Println("main init!")
}

func main() {

	const json = `{"name":{"first":"Janet","last":"四"},"age":47}`
	value := gjson.Get(json, "name.last")
	fmt.Println(value.String())

	var num1 float64 = 3.1
	var num2 float64 = 4.2
	// 如果直接相加，那么结果不是7.3,而是7.3000001，用下面的decimal包可以避免这种情况
	d1 := decimal.NewFromFloat(num1).Add(decimal.NewFromFloat(num2))
	fmt.Println(d1)
	fmt.Println("lala")

	quantity := decimal.NewFromInt(33)
	fmt.Println(quantity)

	var x = 10
	var y = 20

	tools.Multi(x, y)
}
