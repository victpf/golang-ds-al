package tools

import (
	"fmt"
	"goProject/calc"
)

func init() {
	fmt.Println("tools init")
}

func Multi(x, y int) int {
	fmt.Printf("calc.Add: %v",calc.Add(x,y))
	return x*y
}