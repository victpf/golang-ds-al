package main

import (
	"encoding/json"
	"fmt"
)

type Project struct {
	Key   string `json:"key"`
	Value string `json:"value"`
}

type JiraHttpReqField struct {
	Project     `json:",inline"`
	Summary     string `json:"summary"`
	Description string `json:"description"`
}

func main() {
	dataProject := Project{
		Key:   "key1",
		Value: "value1",
	}
	dataJiraHttpReqField := &JiraHttpReqField{
		Project:     dataProject,
		Summary:     "Summary1",
		Description: "Description1",
	}
	data, value := json.Marshal(dataJiraHttpReqField)
	fmt.Println(string(data))
	fmt.Printf("value: %v", value)

}
