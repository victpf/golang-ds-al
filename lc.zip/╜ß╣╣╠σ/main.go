/*
下面的例子显示了5种实例化结构体的方式


*/
package main

import (
	"fmt"
	"encoding/json"
)
//=============================结构体的嵌套，切片============
type Student struct{
	Id int
	Name string
	Gender string

}


type Class struct{
	Title string
	Students []Student 
}

func main(){
	var c = Class{
		Title:"001班",
		Students: make([]Student,0),
	}
	for i := 0; i<20;i++{
		s:= Student{
			Id:i,
			Gender:"男",
			//Sprintf可以用来拼接字符串
			Name:fmt.Sprintf("stu_%v",i),
		}
		c.Students = append(c.Students,s)
	}

	// fmt.Println(c)

	//转化为json

	jsonByte, err:= json.Marshal(c)
	if err != nil{
		fmt.Println(err)
	} else{
		jsonStr := string(jsonByte)
		fmt.Println(jsonStr)
	}

}



//=========================结构体标签，作用就是指定结构体转化为json字符串之后，对应的field的名字===
//注意，下面的json:后面绝对不能有空格，否则我们的配置就会失效
// type Student struct{
// 	Id int `json:"id"`
// 	Gender string `json:"gender"`
// 	Name string `json:"name"`
// 	Sno string `json:"sno"`
// }

// func main(){
// 	var s1 = Student{
// 		Id: 22,
// 		Gender:"男",
// 		Name:"李四",
// 		Sno:"s00001",
// 	}

// 	jsonByte,_ := json.Marshal(s1)

// 	jsonStr := string(jsonByte)
// 	fmt.Println(jsonStr)
// }

//=============================结构体对象和json字符串的互相转化
// type Student struct{
// 	ID int
// 	Gender string
// 	Name string
// 	Sno string
// }

// func main(){
// 	var s1 = Student{
// 		ID: 12,
// 		Gender: "男",
// 		Name:"张三",
// 		Sno:"s0001",
// 	}
// 	fmt.Printf("%#v\n",s1)

// 	//将结构体对象转化为json字符串
// 	jsonByte,_ := json.Marshal(s1)
// 	jsonStr := string(jsonByte)
// 	fmt.Printf("%v\n",jsonStr)


// 	//将json字符串，转化为结构体对象
// 	var str = `{"ID":12,"Gender":"男","Name":"张三","Sno":"s0001"}`
// 	var s2 Student
// 	err := json.Unmarshal([]byte(str),&s2)

// 	if err != nil{
// 		fmt.Println(err)
// 	}

// 	fmt.Printf("s2: %#v\n",s2)
// 	fmt.Println(s2.Name)
// }

//===============================================================================================
// //结构体的继承 --- 本质上是通过结构体的嵌套实现的
// type Animal struct{
// 	name string
// }

// func (a Animal) run(){
// 	fmt.Printf("%v 在运动\n",a.name)
// }

// type Dog struct{
// 	age string
// 	Animal  //结构体的继承 --- 嵌套 也就是说 Dog这个结构体继承了Animal这个结构体
// }

// func (d Dog) wang(){
// 	fmt.Printf("%v 在汪汪汪\n",d.name)
// }

// func main(){
// 	var d = Dog{
// 		age:"3",
// 		Animal:Animal{
// 			name:"阿三",
// 		},
// 	}
// 	d.run()
// 	d.wang()
// }
//=============================================================================
//结构体的嵌套
// type Person struct{
// 	Name string
// 	Age int
// 	Hobby []string
// 	map1 map[string]string
// }

// //结构体的嵌套
// type User struct{
// 	Username string
// 	Passwd string
// 	Sex string
// 	Age int
// 	Address Address 
// }

// type Address struct{
// 	Name string
// 	Phone string
// 	City string
// }

// func main(){
// 	var p Person
// 	p.Name = "张三"
// 	p.Age = 14
// 	p.Hobby = make([]string,3,3)
// 	p.Hobby[0] = "篮球"
// 	p.Hobby[1] = "足球"
// 	p.Hobby[2] = "网球"

// 	p.map1 = make(map[string]string)
// 	p.map1["地址"] = "北京"
// 	p.map1["电话"] = "111111"
// 	// fmt.Println(p)
// 	fmt.Printf("%#v\n",p)


// 	var u User
// 	u.Username = "zhangsan"
// 	u.Passwd = "123456"
// 	u.Address.Name = "李四"
// 	u.Address.Phone = "11111112"
// 	u.Address.City = "北京"
// 	fmt.Printf("%#v",u)

// }

//结构体名字首字母小写 --- 私有结构体
//结构体名字首字母大写 --- 共有结构体
// type Person struct{
// 	name string
// 	age  int
// 	sex  string
// 	height int
// }

// //定义结构体方法
// func (p Person) PrintInfo(){
// 	fmt.Printf("name: %v, age: %v\n",p.name,p.age)
// }

// //定义设置结构体属性的方法
// //注意，这里p必须使用指针类型，否则无法修改给定的结构体实例的属性
// func (p *Person) SetInfo(name string, age int){
// 	p.name = name 
// 	p.age = age
// }

// func main(){

// 	//实例化结构体1
// 	// var p1 Person
// 	//实例化结构体 - 2
// 	// var p1 = new(Person)
// 	//实例化结构体 - 3
// 	// var p1 = &Person{}
// 	//实例化结构体 - 4   
// 	//注意每一行都得加上逗号
// 	// var p1 = Person{
// 	// 	name:"ZHANG SI",
// 	// 	age:23,
// 	// 	sex:"Male",
// 	// }

// 	//初始化结构体 - 5
// 	// var p1 = &Person{
// 	// 	name:"张武",
// 	// 	age:35,
// 	// 	sex:"男的",
// 	// }
// 	// p1.name = "ZHANG SAN"
// 	// p1.age = 20
// 	// p1.sex = "Male"
// 	// fmt.Printf("P1 :%#v",p1)

// 	// var p = Person{
// 	// 	name: "张三",
// 	// 	age:12,
// 	// 	sex: "男",
// 	// 	height: 120,
// 	// }
// 	// p.PrintInfo()
// 	// p.SetInfo("李四",66)
// 	// p.PrintInfo()
// }