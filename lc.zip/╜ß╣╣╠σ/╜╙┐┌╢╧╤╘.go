package main

import (
	"fmt"
	"math"
)

//1. 定义一个接口
type Shape struct{
	peri() float64 
	area() float64 
}

//2.定义一个结构体实现上面的接口
type Triangle struct {
	a,c,b float64 
}

func peri(t Triangle) float64 {
	return t.a + t.b + t.c 
}

func area(t Triangle) float64{
	p := t.peri()/2
	s := math.Sqrt(p*(p-t.a)*(p-t.b)*(p-t.c))
	return s 
}

// 2. 定义第二个结构体实现上面的接口
type Circle struct{
	radius float64
}

func(c Circle) peri() float64{
	return c.radius*2*math.Pi
}

func (c Circle) area() float64 {
	return math.Pow(c.radius,2) * math.Pi
}

func main(){
	var t1 = Triangle{a:1,b:4,c:5}
	fmt.Println(t1.peri())
	fmt.Println(t1.area())
	fmt.Println(t1.a, t1.b, t1.c)
}