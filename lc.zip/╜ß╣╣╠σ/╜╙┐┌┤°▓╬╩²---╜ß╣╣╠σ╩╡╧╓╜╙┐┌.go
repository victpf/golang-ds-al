package main

import "fmt"

type Animal interface {
	GetName() string
	SetName(string)
}

type Dog struct {
	Name string
}

func (d *Dog) GetName() string {
	return d.Name
}

func (d *Dog) SetName(name string) {
	d.Name = name
}

func main() {
	var dog = &Dog{
		Name: "小花",
	}

	var animal Animal = dog
	fmt.Println(animal.GetName())
	animal.SetName("小叶")
	fmt.Println(animal.GetName())
}
