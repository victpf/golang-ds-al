package main

import "fmt"

//定义接口
type Usb interface {
	start()
	stop()
}

//定义结构体
type Phone struct {
	Name string
}

//定义结构体方法，由于我们想要用这个结构体实现上面的接口
//所以我们要定义的结构体方法就是start() stop()
//1. 值接收者方法
func (p *Phone) start() {
	fmt.Println(p.Name, "开机")
}

func (p *Phone) stop() {
	fmt.Println(p.Name, "关机")
}

//下面的例子可以看出
//当我们的结构体方法是值接收者的时候
//我们的结构体初始化可以用下面两种中的人何一种都可以
//但是如果我们的结构体方法是指针接收者
//那么我们就只能用第二种方法
func main() {

	//使用指针初始化结构体
	var p2 = &Phone{
		Name: "小米手机",
	}

	var usb2 Usb = p2
	usb2.stop()
}
