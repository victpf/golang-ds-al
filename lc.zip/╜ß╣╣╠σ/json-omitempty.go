package main

import (
	"encoding/json"
	"fmt"
)

type address struct {
	Street  string `json:"street"`  // 街道
	Ste     string `json:"suite"`   // 单元（可以不存在）
	City    string `json:"city"`    // 城市
	State   string `json:"state"`   // 州/省
	Zipcode string `json:"zipcode"` // 邮编

}

type addressOmitEnpty struct {
	Street     string     `json:"street"`          // 街道
	Ste        string     `json:"suite,omitempty"` // 单元（可以不存在）
	City       string     `json:"city"`            // 城市
	State      string     `json:"state"`           // 州/省
	Zipcode    string     `json:"zipcode"`         // 邮编
	Coordinate coordinate `json:"coordinate,omitempty"`
}

type addressOmitEnptyForStructAttri struct {
	Street     string      `json:"street"`          // 街道
	Ste        string      `json:"suite,omitempty"` // 单元（可以不存在）
	City       string      `json:"city"`            // 城市
	State      string      `json:"state"`           // 州/省
	Zipcode    string      `json:"zipcode"`         // 邮编
	Coordinate *coordinate `json:"coordinate,omitempty"`
}

type coordinate struct {
	Lat *float64 `json:"latitude"`
	Lng *float64 `json:"longitude"`
}

type coordinate1 struct {
	Lat float64 `json:"latitude,omitempty"`
	Lng float64 `json:"longitude,omitempty"`
}

//为了解决0，0被omitempty错误的忽略的问题
type coordinate2 struct {
	Lat *float64 `json:"latitude,omitempty"`
	Lng *float64 `json:"longitude,omitempty"`
}

func main() {

	jsonStr := `{
		"street": "200 Larkin St",
        "city": "San Francisco",
        "state": "CA",
        "zipcode": "94102"
	}`

	addr := new(address)
	//将json字符串转换为struct
	json.Unmarshal([]byte(jsonStr), &addr)
	// fmt.Printf("addr struct: %v", addr)
	// MarshalIndent和Marshal的区别就在于输出的格式，没有本质区别
	//他有三个参数，第一个就是我们的结构体，第二个就是前缀，第三个就是换行符号
	addressBytes, _ := json.MarshalIndent(addr, "", "    ")
	fmt.Printf("Struct-addr: %s\n", string(addressBytes))
	/* 下面是输出，可以看到suite这里是空值
		addr struct: &{200 Larkin St  San Francisco CA 94102}{
	    "street": "200 Larkin St",
	    "suite": "",
	    "city": "San Francisco",
	    "state": "CA",
	    "zipcode": "94102"
		}
	*/

	//下面我们给suite加上omitempty选项，这样的话，如果是空的值，这个cloumn就不会出现在转化之后的结构体中了
	addrOmit := new(addressOmitEnpty)
	//将json字符串转换为struct
	json.Unmarshal([]byte(jsonStr), &addrOmit)
	// fmt.Printf("addr struct: %v", addrOmit)
	addressBytesOmit, _ := json.MarshalIndent(addrOmit, "", "    ")
	fmt.Printf("Struct-addrOmit: %s\n", string(addressBytesOmit))
	/* 这是现在的输出：可以看到已经没有了suite这个column
		addr struct: &{200 Larkin St  San Francisco CA 94102}{
	    "street": "200 Larkin St",
	    "city": "San Francisco",
	    "state": "CA",
	    "zipcode": "94102"
	}
	*/

	//但是上面的操作omitempty，只对非结构体的属性有效，如果某个属性是另一个结构体，那么就不起作用了
	//给addressOmitEmpty这个结构体加上coordinate这个结构体作为属性，然后同样赋值上面json字符串，就能看到下面的结果
	/*
			addr struct: &{200 Larkin St  San Francisco CA 94102 {0 0}}{
		    "street": "200 Larkin St",
		    "city": "San Francisco",
		    "state": "CA",
		    "zipcode": "94102",
		    "coordinate": {
		        "latitude": 0,
		        "longitude": 0
		    }
		}
	*/

	//为了解决omitempty对属性是结构体的情况不生效的问题，我们修改了之前的结构体的定义
	//对是结构体这个属性，把他定义为指向结构体地址的指针,这样的话，结构体作为属性，也可以
	//被omitempty这个option锁管理生效了
	addrOmitStruct := new(addressOmitEnptyForStructAttri)
	//将json字符串转换为struct
	json.Unmarshal([]byte(jsonStr), &addrOmitStruct)
	addressBytesOmitForStructAttri, _ := json.MarshalIndent(addrOmitStruct, "", "    ")
	fmt.Printf("Struct-addrOmitStruct: %s\n", string(addressBytesOmitForStructAttri))
	/* 经过处理，下面就是新的结果，可以看到结构体的属性已经不存在了
		{
	    "street": "200 Larkin St",
	    "city": "San Francisco",
	    "state": "CA",
	    "zipcode": "94102"
	}
	*/
	//==================================================================
	//但是，还有一种情况，就是我们本身的值就是0，那么如果我们使用上面的方法的话，也会被忽略，这样的话，其实结果就不正确了
	//例如：输出将会是{}
	cData := `{
        "latitude": 0.0,
        "longitude": 0.0
    }`
	c := new(coordinate1)
	json.Unmarshal([]byte(cData), &c)

	coordinateBytes, _ := json.MarshalIndent(c, "", "    ")
	fmt.Printf("Struct-coordinate1: %s\n", string(coordinateBytes))
	//为了解决上面的问题，我们需要做下面的事情
	//就是将coordinate这个结构体的属性变为指针
	/*
			type coordinate1 struct {
			Lat *float64 `json:"latitude,omitempty"`
			Lng *float64 `json:"longitude,omitempty"`
		}
	*/
	//注意，如果是前面的那种情况addrOmit ，就是有一个属性是另一个结构体，如果这时候将coordinate这个结构体的属性都变为指针
	//那么我们将无法得到
	/*
						Struct-addrOmit: {
					    "street": "200 Larkin St",
					    "city": "San Francisco",
					    "state": "CA",
					    "zipcode": "94102",
					    "coordinate": {
					        "latitude": 0,
					        "longitude": 0
					    }
					}
				我们得到的会变成下面这个，其实也没有解决根本问题，所以要解决结构体作为属性的问题，必须将结构体这个属性设为指针
		Struct-addrOmit: {
		    "street": "200 Larkin St",
		    "city": "San Francisco",
		    "state": "CA",
		    "zipcode": "94102",
		    "coordinate": {
		        "latitude": null,
		        "longitude": null
		    }
		}

	*/
	c2 := new(coordinate2)
	json.Unmarshal([]byte(cData), &c2)

	coordinateBytes2, _ := json.MarshalIndent(c2, "", "    ")
	fmt.Printf("Struct-coordinate2: %s\n", string(coordinateBytes2))
}
