package main

import "fmt"

//定义接口
type Usb interface {
	start()
	stop()
}

//定义结构体
type Phone struct {
	Name string
}

//定义结构体方法，由于我们想要用这个结构体实现上面的接口
//所以我们要定义的结构体方法就是start() stop()
//1. 值接收者方法
func (p Phone) start() {
	fmt.Println(p.Name, "开机")
}

func (p Phone) stop() {
	fmt.Println(p.Name, "关机")
}

func main() {
	var p1 = Phone{
		Name: "小米手机",
	}

	var usb Usb = p1
	usb.start()

	//使用指针初始化结构体
	var p2 = &Phone{
		Name: "小米手机",
	}

	var usb2 Usb = p2
	usb2.stop()
}
