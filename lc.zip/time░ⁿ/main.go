package main

import (
	"fmt"
	"time"
)

func main(){
	// timeObj := time.Now()
	// fmt.Println(timeObj)

	// year := timeObj.Year()
	// month := timeObj.Month()
	// day := timeObj.Day()
	// hour := timeObj.Hour()
	// minute := timeObj.Minute()
	// second := timeObj.Second()
	// //02d表示只显示2位数，如果不够的话，会在前面补上一个0
	// fmt.Printf("%02d-%02d-%02d %02d:%02d:%02d",year,month,day,hour,minute,second)


	// //另外一种格式化时间的方法
	// var timeObj = time.Now()
	// //注意，后面的15 如果写成15，那么就代表我们要24小时制
	// // 如果写的是3，代表我们想要12小时制
	// var template = timeObj.Format("2006-02-02 15:04:05")
	// fmt.Println(template)

	// //获取当前的时间戳  1970.1.1 到现在的总毫秒数
	// timeObj := time.Now()
	// timestamp := timeObj.Unix()
	// fmt.Println(timestamp)
	// timeNastamp := timeObj.UnixNano()
	// fmt.Println(timeNastamp)


	// //将时间戳的形式转换为标准的日期格式
	// timeRecv := time.Unix(0,int64(1609741039871163200))
	// timeRecvF := timeRecv.Format("2006-02-02 15:04:05")
	// fmt.Println(timeRecvF)


	//字符串转化为时间戳
	// var str = "2021-01-04 15:38:20"
	// var template = "2006-02-02 15:04:05"
	// var timeObj,_ = time.ParseInLocation(template,str,time.Local)
	// fmt.Println(timeObj)
	// fmt.Println(timeObj.Unix())

	//go实现定时器
	ticker := time.NewTicker(time.Second)
	n := 5
	for val := range ticker.C{
		n--
		fmt.Println(val)
		if n ==0{
			//加了stop方法之后，代表将这个程序从内存中彻底清掉
			ticker.Stop()
			//如果不加stop 只用break,那么程序还会在内存中，只不过跳出了循环
			break
		}
	}


}