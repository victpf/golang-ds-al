package 找到链表的倒数第K个元素

import (
	"fmt"
	. "github.com/isdamir/gotype"
)

func reverse(head *LNode)  {
	if head == nil || head.Next == nil {
		return
	}
	firstNode := head.Next
	pre := head
	for firstNode != nil {
		// 备份下一个节点
		tmp := firstNode.Next
		// 修改第一个节点的指向
		firstNode.Next = pre
		// pre向前走一位
		pre = firstNode
		//
		firstNode = tmp
	}
	head.Next = pre
}

func findKthReversedList(head *LNode, k int) *LNode {
	reverse(head)
	PrintNode("head: ",head)
	firstNode := head.Next
	for i := 0; i < k-1; i++ {
		firstNode = firstNode.Next
	}
	return firstNode
}

func main() {
	head := &LNode{}
	CreateNode(head, 9)
	kThNode := findKthReversedList(head,2)
	fmt.Println("kth: ",kThNode.Data)
}
