package main

import (
	"fmt"
	. "github.com/isdamir/gotype"
)

func findLastKthElem(head *LNode, k int) *LNode {
	if head == nil || head.Next == nil {
		return head
	}
	slow := head
	fast := head
	var i int
	for i = 0; i < k && fast != nil; i++ {
		fast = fast.Next
	}
	// 上面的循环结束之后，i=k
	fmt.Println("i: ", i, " k: ", k)
	if i < k {
		return nil
	}
	// 实际上我们是想要正数第n-k个元素，但是因为是链表，我们不知道总长度，所以使用快慢指针法，
	// 让fast 指针先走k个位置，然后slow指针从头开始，fast指针从k开始，一直到fast指针走到最后的时候，
	// 说明slow指针就找到了n-k个位置了
	for fast != nil{
		slow = slow.Next
		fast = fast.Next
	}
	return slow
}


func main() {
	head := &LNode{}
	CreateNode(head, 9)
	kThNode := findLastKthElem(head,2)
	fmt.Println("kth: ",kThNode.Data)
}