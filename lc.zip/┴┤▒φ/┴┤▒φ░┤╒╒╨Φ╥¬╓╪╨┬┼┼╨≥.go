package main

import . "github.com/isdamir/gotype"

// 按照每K个node全部重新排序
// 使用递归

func ReverseKGroup(head *LNode, k int) *LNode {
	node := head
	for i := 0; i < k; i++ {
		if node == nil {
			return head
		}
		node = node.Next
	}
	// 将第一部分反转
	newHead := ReverseList(head, node)
	// 递归
	head.Next = ReverseKGroup(node, k)
	return newHead
}

func ReverseList(start, end *LNode) *LNode {
	pre := &LNode{}
	for start != end {
		//备份第二个节点
		tmp := start.Next
		start.Next = pre
		pre = start
		start = tmp
	}
	return end
}
