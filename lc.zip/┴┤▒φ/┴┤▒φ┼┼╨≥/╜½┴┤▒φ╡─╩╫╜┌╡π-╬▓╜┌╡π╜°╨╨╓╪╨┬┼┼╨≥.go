package main

import (
	"fmt"
	. "github.com/isdamir/gotype"
)

// 找到链表的中间节点
func findMiddleNode(head *LNode) *LNode {
	if head == nil || head.Next == nil {
		return head
	}
	slowPre := head
	slow := head
	fast := head
	for fast != nil && fast.Next != nil {
		slowPre = slow
		// 向前走一个节点
		slow = slow.Next
		// 向前走两步
		fast = fast.Next.Next
	}
	slowPre.Next = nil
	return slow
}

func reverse(head *LNode) *LNode {
	if head == nil || head.Next == nil {
		return head
	}
	// 如果head是一个空节点1，那么这里就要head.Next，否则就是现在这样
	firstNode := head
	pre := &LNode{}
	for firstNode != nil {
		tmp := firstNode.Next
		firstNode.Next = pre
		pre = firstNode
		firstNode = tmp
	}
	head = pre
	return head
}

// head是一个空的节点
func ReverseAsNeeded(head *LNode) {
	if head == nil || head.Next == nil {
		return
	}
	// 前半部分第一个节点
	cur1 := head.Next
	mid := findMiddleNode(head.Next)
	fmt.Println("mid: ",mid.Data)
	// mid返回的是下半部分链表的第一个节点，下面是调用反转链表的函数，将下半部分的链表反转
	cur2 := reverse(mid)
	fmt.Println("cur2: ",cur2.Data)
	var tmp *LNode
	// 合并上半部分链表(cur1)和已经反转的下半部分链表(cur2)
	for cur1.Next != nil {
		// 因为需要向前挪动cur1,所以备份cur1的下一个节点
		tmp = cur1.Next
		// 将前半部分的头节点指向下半部分的头节点
		cur1.Next = cur2
		// 前半部分头节点向前挪一个位置
		cur1 = tmp

		// 由于cur2也要向前走，所以备份cur2的下一个节点
		tmp = cur2.Next
		// 将下半部分的头节点指向上半部分的新的cur1（前面的代码已经让他向前走了一位，相当于是原来的第二个节点）
		cur2.Next = cur1
		// 下半部分向前挪一位
		cur2 = tmp
	}
	cur1.Next = cur2
}

func main() {
	fmt.Println("链表按需排序")
	head := &LNode{}
	CreateNode(head,9)
	PrintNode("排序前",head)
	ReverseAsNeeded(head)
	PrintNode("排序后: ",head)
}
