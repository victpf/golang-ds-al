package main

import "fmt"

var count int
func Recursive(nums []int){
	count ++
	fmt.Println("nums: ",nums)
	prt := len(nums)/2
	fmt.Println("prt: ",prt)

	if prt <1 {
		return
	}
	Recursive(nums[:prt])
	Recursive(nums[prt:])
	fmt.Println("++++++++++++++++++++++")
}
func main(){
	nums := []int{1,2,3,4,5,6,7,8}
	Recursive(nums)
}