package main

import (
	"fmt"
)

type LNode struct {
	Data int
	Next *LNode
}

func mergeKSortedLists(part string, lists []*LNode) *LNode {
	fmt.Println("")
	fmt.Println("part: ", part)
	length := len(lists)
	fmt.Println("length: ", length)
	if length < 1 {
		return nil
	}
	if length == 1 {
		return lists[0]
	}
	num := length / 2
	fmt.Println("num: ", num)
	left := mergeKSortedLists("left", lists[:num])
	right := mergeKSortedLists("right", lists[num:])
	fmt.Println("+============================")

	return mergeTwoSortedList(left, right)

}
func mergeTwoSortedList(l1, l2 *LNode) *LNode {
	if l1 == nil {
		return l2
	}

	if l2 == nil {
		return l1
	}

	if l1.Data < l2.Data {
		l1.Next = MergeTwoSortedList(l1.Next, l2)
		return l1
	}
	l2.Next = MergeTwoSortedList(l1, l2.Next)
	return l2
}
func createNode(node *LNode, max int) {
	start := node
	for i := 0; i < max; i++ {
		tmp := &LNode{
			Data: i,
			Next: nil,
		}
		start.Next = tmp
	}
}
func main() {
	lst1 := &LNode{}
	createNode(lst1, 3)
	lst2 := &LNode{}
	createNode(lst2, 4)
	lst3 := &LNode{}
	createNode(lst3, 5)
	lst4 := &LNode{}
	createNode(lst4, 66)
	lists := []*LNode{lst1, lst2, lst3, lst4}
	mergeKSortedLists("start", lists)
}
