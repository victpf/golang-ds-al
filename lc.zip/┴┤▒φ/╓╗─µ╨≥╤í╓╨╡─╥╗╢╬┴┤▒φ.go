package main

import . "github.com/isdamir/gotype"

func ReverseBetween(head *LNode, m, n int) *LNode {
	if head == nil || m >= n {
		return nil
	}
	newHead := &LNode{
		Data: 0,
		Next: head,
	}
	//按照顺序移动到第m个节点
	pre := newHead
	for count := 0; pre.Next != nil && count < m-1; count++ {
		pre = pre.Next
	}

	if pre.Next == nil {
		return head
	}

	//头插法逆序排m-n之间的链表
	cur := pre.Next
	for i := 0; i < n-m; i++ {
		// 备份目前处于第一位的节点
		tmp := pre.Next
		// 头节点的下一个节点指向我们即将要拿出来放第一位的节点
		pre.Next = cur.Next
		// cur节点一直不变，现在是吧他指向她 后后面一个节点，因为之前她后面的节点要被拿到第一位
		cur.Next = cur.Next.Next
		// 吧2中指向的节点的下一个节点指向tmp，也就是之前一次结束后排第一的节点
		pre.Next.Next = tmp
	}
	return newHead.Next
}
