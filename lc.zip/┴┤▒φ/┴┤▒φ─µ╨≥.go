package main

import (
	"fmt"
	. "github.com/isdamir/gotype"
)

func Reverse(node *LNode) {
	if node == nil || node.Next == nil {
		return
	}

	firstNode := node.Next
	var pre *LNode
	var curr *LNode

	for firstNode != nil {
		curr = firstNode.Next
		// 让当前第一个节点的下一个节点变成一个空节点
		firstNode.Next = pre
		// 将第一个节点变成pre节点，这是为了下一次循环的时候，使用上面一行代码，他后面的节点指向她
		pre = firstNode
		// 当前的节点往前移一个位子
		firstNode = curr
	}
	// 最后，让一开始的链表的头地址的下一个地址指向反转之后的第一个节点的地址
	node.Next = pre
}

func main() {
	head := &LNode{}
	fmt.Println("就地排序")
	CreateNode(head, 8)
	PrintNode("排序前: ", head)
	Reverse(head)
	PrintNode("排序后: ", head)
}
