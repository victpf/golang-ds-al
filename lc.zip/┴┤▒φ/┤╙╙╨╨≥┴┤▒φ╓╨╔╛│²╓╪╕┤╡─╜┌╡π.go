package main

import . "github.com/isdamir/gotype"

func ReverseSortedList(head *LNode) *LNode {
	cur := head
	if head == nil {
		return nil
	}
	if head.Next == nil {
		return head
	}

	for cur.Next != nil {
		// 如果当前节点的值和后面一个一样，那么就让当前节点直接指向下下一个节点（相当于删除了下一个节点）
		if cur.Data == cur.Next.Data {
			cur.Next = cur.Next.Next
		} else {
			// 否则，继续下一个节点
			cur = cur.Next
		}
	}
	return head
}
