package main

import . "github.com/isdamir/gotype"

func ReverseUnsortedList(head *LNode) *LNode {
	seenMap := make(map[interface{}]*LNode)
	cur := head
	if head == nil {
		return nil
	}
	if head.Next == nil {
		seenMap[head.Data] = head
		return head
	}

	for cur.Next != nil {
		if _, ok := seenMap[cur.Next.Data]; ok {
			cur.Next =cur.Next.Next
		} else{
			seenMap[cur.Next.Data] = cur.Next
			cur = cur.Next
		}
	}
	return head
}

func main(){
	head := &LNode{}
	CreateNode(head,9)
	PrintNode("head: ",head)
	start := head.Next

	node := &LNode{
		Data: 3,
		Next: start,
	}

	node0 := &LNode{
		Data: 0,
		Next: node,
	}
	ReverseUnsortedList(node0)
	PrintNode("node0:",node0)
}
