package main

import (
	"fmt"
	. "github.com/isdamir/gotype"
)

func main() {
	head := &LNode{}
	CreateNode(head, 20)
	pre := head
	cur := head.Next
	fmt.Println("cur: ", cur.Data)
	fmt.Println("head: ", head.Data)
	for i := 2; i < 5; i++ {
		fmt.Println("")

		// 备份头节点
		tmp := pre.Next
		fmt.Println("tmp0: ", tmp.Data)
		fmt.Println("pre: ", pre.Data)
		// 跳过即将放到头节点前面的节点，指向后面的后面这个节点
		pre.Next = cur.Next
		fmt.Println("pre.next:", pre.Next.Data)
		// 将第三个节点插入到第二个节点前面
		cur.Next = cur.Next.Next
		fmt.Println("cur.Next.Next: ", cur.Next.Next.Data)
		// 第二个节点指向头节点
		pre.Next.Next = tmp
		fmt.Println("tmp1: ", tmp.Data)
		PrintNode("head----",head)
		fmt.Println("cur----",cur.Data)
		fmt.Println("pre----",pre.Data)
		fmt.Println("============================")
	}
	PrintNode("cur: ", cur)
	PrintNode("head: ", head)
}
