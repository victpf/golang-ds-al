package main

import . "github.com/isdamir/gotype"

func ReverseBetweenSelected(head *LNode, m, n int) *LNode {
	if head == nil || m >= n {
		return nil
	}

	if head.Next == nil {
		return head
	}

	newHead := &LNode{
		Data: 0,
		Next: head,
	}
	pre := newHead
	for count := 0; count < m-1 && pre.Next != nil; count++ {
		pre = pre.Next
	}

	if pre.Next == nil{
		return head
	}

	cur := pre.Next
	for i:=0;i<n-m;i++{
		tmp := pre.Next
		pre.Next = cur.Next
		cur.Next = cur.Next.Next
		pre.Next.Next = tmp
	}
	return newHead.Next
}
