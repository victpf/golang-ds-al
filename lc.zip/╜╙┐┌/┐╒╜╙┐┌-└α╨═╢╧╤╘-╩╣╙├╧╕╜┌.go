package main

import "fmt"

type Addr struct{
	Name string
	Phone int
}

func main(){

	var userinfo = make(map[string]interface{})

	userinfo["username"] = "张三"
	userinfo["age"] = 20
	userinfo["hobby"] = []string{"学习","进步"}

	var addr = Addr{
		Name:"李四",
		Phone: 11111111,
	}

	userinfo["address"] = addr
	fmt.Println(userinfo)
	/*
	注意，我们目前这个map中，address和hobby的值分别是一个结构体和一个切片，但是我们不能用下面的代码获取结构体和切片中的具体属性
	var address = userinfo["address"].Name
	var hob = userinfo["hobby"][0]
	这都是错误的代码。
	*/


	//如果我们一定想要通过map获得这些值的具体属性，那么需要用类型断言实现

	hobb,_ := userinfo["hobby"].([]string)
	fmt.Println(hobb[0])

	phone ,_ := userinfo["address"].(Addr)
	fmt.Println(phone.Name)
}