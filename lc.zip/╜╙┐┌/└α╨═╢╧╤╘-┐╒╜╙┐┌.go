package main

import (
	"fmt"
)

func main() {
	var x interface{}
	x = "你好"
	value,status := x.(string)
	if status {
		fmt.Printf("x 就是字符串，值是%v",value)
	} else {
		fmt.Println("x 不是字符串")
	}

}