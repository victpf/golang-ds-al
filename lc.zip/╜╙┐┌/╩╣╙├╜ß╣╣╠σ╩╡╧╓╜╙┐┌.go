package main

import (
	"fmt"
)

type Usb interface{
	start()
	stop()
}

//电脑
type Computer struct{}

func (c Computer) work(u Usb){
	u.start()
	u.stop()
}

//电话
type Phone struct{
	Name string
}

func (p Phone) start(){
	fmt.Println(p.Name, "开机")
}

func (p Phone) stop() {
	fmt.Println(p.Name, "关机")
}

//相机

type Camera struct{}

func (c Camera) start(){
	fmt.Println("相机启动")
}

func (c Camera) stop(){
	fmt.Println("相机关闭")
}

func main(){
	var p = Phone{
		Name:"小米",
	}

	var c Camera

	var computer Computer

	//work方法定义的输入类型是Usb,所以下面的操作相当于是将P和c赋值给Usb类型的实例
	//正好是相当于我们将结构体和接口相关联起来了
	computer.work(p)
	computer.work(c)

	var usb Usb

	usb = p 
	usb.start()


}