package main

type myType string 
const (
	var Started myType = "开始了"
)