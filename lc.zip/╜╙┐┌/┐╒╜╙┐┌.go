package main

import (
	"fmt"
)

//空接口
func main(){
	//让切片接受任意类型数据
	var slice = []interface{}{}
	slice = make([]interface{},3,3)
	slice[0] = 11
	slice[1] = "Hello"
	slice[2] = true
	fmt.Println(slice) 

	//让map的值变成可以是任意类型的数据
	var map1 = make(map[string]interface{})
	map1["ID"] = 11111
	map1["name"] = "李四"
	map1["gender"] = true
	fmt.Printf("%#v",map1)
}