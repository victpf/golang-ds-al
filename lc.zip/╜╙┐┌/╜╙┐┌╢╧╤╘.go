package main

import (
	"fmt"
	"math"
)

func main() {
	var t1 = Triangle{a: 3, b: 4, c: 5}
	fmt.Println(t1.peri())
	fmt.Println(t1.area())
	fmt.Println(t1.a, t1.b, t1.c)

	//实现接口
	// 注意，这里不能用s1.a s1.b s1.c
	// 因为s1是接口类型，接口类型不能访问实现她的结构体的属性字段\
	var s1 Shape
	s1 = t1
	fmt.Println(s1.peri())
	fmt.Println(s1.area())

	// 实例化一个 Circle
	var c1 = Circle{radius: 3}
	fmt.Println(c1.peri())
	fmt.Println(c1.area())
	fmt.Println(c1.radius)

	//Circle实现接口Shape
	var s2 Shape
	s2 = c1
	fmt.Println(s2.peri())
	fmt.Println(s2.area())

	// 接口断言
	/*
		1. 方式1：
			instance := 接口对象.(实际类型)  // 不安全，容易panic
			instance, ok := 接口对象.(实际类型) //安全
		2. 方式2：
			switch instance := 接口对象.(type){
				case 实际类型1：
					。。。
				case 实际类型2：
					。。。
			}
	*/
	getType(s1)
	getType(s2)
	getType(t1)
	getType(c1)
	fmt.Println("-------------------")
	getTypeSwitch(s1)
	getTypeSwitch(s2)
	getTypeSwitch(t1)
	getTypeSwitch(c1)

}

func getTypeSwitch(s Shape) {
	switch ins := s.(type) {
	case Triangle:
		fmt.Println("是三角形，长宽高： ", ins.a, ins.b, ins.c)
	case Circle:
		fmt.Println("是圆形， 半径是：", ins.radius)
	default:
		fmt.Println("我也不知道了")
	}
}

// 1. 这个函数的参数类型是接口，然后传入之后，可以断言实现这个接口的结构体的类型
// 2. 结构体的类型和结构体指针不是一回事
// 3. 断言获得的ins变量，和原来的结构体只是内容一样，ins是在内存中新生成的
func getType(s Shape) {
	if ins, ok := s.(Triangle); ok {
		fmt.Println("是三角形，三边是：", ins.a, ins.b, ins.c)
	} else if ins, ok := s.(Circle); ok {
		fmt.Println("是圆形，半径是： ", ins.radius)
	} else {
		fmt.Println("未知类型")
	}
}

//1. 定义一个接口
type Shape interface {
	peri() float64
	area() float64
}

//2.定义一个结构体实现上面的接口
type Triangle struct {
	a, c, b float64
}

func (t Triangle) peri() float64 {
	return t.a + t.b + t.c
}

func (t Triangle) area() float64 {
	p := t.peri() / 2
	s := math.Sqrt(p * (p - t.a) * (p - t.b) * (p - t.c))
	return s
}

// 2. 定义第二个结构体实现上面的接口
type Circle struct {
	radius float64
}

func (c Circle) peri() float64 {
	return c.radius * 2 * math.Pi
}

func (c Circle) area() float64 {
	return math.Pow(c.radius, 2) * math.Pi
}
