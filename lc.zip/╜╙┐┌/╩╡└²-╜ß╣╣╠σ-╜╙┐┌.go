package main

import (
	"fmt"
)

type Animal interface{
	SetName(string)
	GetName() string
}

type Dog struct{
	Name string 
}

func (d *Dog) SetName(name string){
	d.Name = name
}

func (d Dog) GetName() string{
	return d.Name
}

type Cat struct{
	Name string
}

func (c *Cat) SetName(name string){
	c.Name = name 
}

func (c Cat) GetName() string{
	return c.Name
}

func main(){
	var d = &Dog{
		Name:"小花",
	}

	var a Animal = d
	fmt.Println(a.GetName())
	a.SetName("小叶")
	fmt.Println(a.GetName())

	var c = &Cat{
		Name:"小喵",
	}

	var b Animal = c 
	fmt.Println(b.GetName())
	b.SetName("大喵")
	fmt.Println(b.GetName())


}